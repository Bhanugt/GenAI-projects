from flask import Flask, render_template, request
from transformers import pipeline

app = Flask(__name__)

# Load AI text generation model
generator = pipeline("text-generation", model="gpt2")

@app.route("/", methods=["GET", "POST"])
def home():
    quote = ""
    if request.method == "POST":
        prompt = request.form["prompt"]
        result = generator(
            prompt,
            max_length=50,
            num_return_sequences=1
        )
        quote = result[0]["generated_text"]

    return render_template("index.html", quote=quote)

if __name__ == "__main__":
    app.run(debug=True)
