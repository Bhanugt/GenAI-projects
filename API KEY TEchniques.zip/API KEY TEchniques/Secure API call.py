import os
import requests

api_key = os.getenv("API_KEY")

HEADERS = {
    "Authorization": f"Bearer {api_key}"
}

response = requests.get("https://api.example.com/sate", headers=HEADERS)
print(response.json())
