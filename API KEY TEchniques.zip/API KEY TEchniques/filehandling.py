with open("example.txt", "w")  as f:
     f.write("python File Handling\n")
with open("example.txt", "a") as f:
     f.write("Easy and powerful\n")
with open("example.txt", "r") as f:
    print(f.read())
#create&write to a File
file = open("student.txt", "w")
file.write("Bhanu.txt\n")
file.close()
#Append data to a file
file = open("student.txt", "a")
file.write("Grade: A\n")
file.close()