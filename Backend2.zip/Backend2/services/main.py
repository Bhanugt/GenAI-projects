import asyncio
from fastapi import FastAPI
from app.models import PromptRequest
from app.services.openai_service import call_openai
from app.services.gemini_service import call_gemini
from app.services.claude_service import call_claude

app = FastAPI(title="LLM Comparison API")


@app.post("/compare")
async def compare_llms(data: PromptRequest):
    prompt = data.prompt

    loop = asyncio.get_running_loop()

    openai_task = loop.run_in_executor(None, call_openai, prompt)
    gemini_task = loop.run_in_executor(None, call_gemini, prompt)
    claude_task = loop.run_in_executor(None, call_claude, prompt)

    openai_res, gemini_res, claude_res = await asyncio.gather(
        openai_task,
        gemini_task,
        claude_task
    )

    return {
        "openai": openai_res,
        "gemini": gemini_res,
        "claude": claude_res
    }
