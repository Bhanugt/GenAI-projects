import google.generativeai as genai
from config import GEMINI_API_KEY

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)

# Create model instance
model = genai.GenerativeModel("gemini-pro")

def call_gemini(prompt: str):
    response = model.generate_content(prompt)
    return response.text
