from openai import openAI
from config import OPENAI_API_KEY
client = OpenAI(api_key=OPENAI_API_KEY)
def call_OPENAI(prompt: str):
    response = client.chat.completions.create(
        model="gpt-40-mini",
        max_tokens=500,
        messages=[
            {"role":"user", "context": prompt}
        ]
    )
    return response.choices[0].message,content
