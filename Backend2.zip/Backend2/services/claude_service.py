from anthropic import anthropic
from config import CLAUDE_API_KEY
client = Anthropic(api_key=CLAUDE_API_KEY)
def call_claude(prompt: str):
    response = client.messages.create(
        model="claude-3-haiku-2040307",
        max_tokens=500,
        messages=[
            {"role":"user", "context": prompt}
        ]
    )
    return response.context[0].text
