from flask import Flask
from ratelimiting import rate_limit

app = Flask(__name__)

@app.route("/api")
@rate_limit()
def api():
    return {"message": "Request successful"}

if __name__ == "__main__":
    app.run(debug=True)
