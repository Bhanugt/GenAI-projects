import time
from functools import wraps
from flask import request, jsonify


class TokenBucket:
    def __init__(self, capacity, refill_rate):
        self.capacity = capacity
        self.tokens = capacity
        self.refill_rate = refill_rate
        self.last_refill = time.time()

    def allow_request(self):
        now = time.time()
        elapsed = now - self.last_refill

        self.tokens = min(
            self.capacity,
            self.tokens + elapsed * self.refill_rate
        )
        self.last_refill = now

        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False


# One bucket per client (IP)
buckets = {}

MAX_REQUESTS = 5
TIME_WINDOW = 60
REFILL_RATE = MAX_REQUESTS / TIME_WINDOW


def rate_limit():
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            client_ip = request.remote_addr

            if client_ip not in buckets:
                buckets[client_ip] = TokenBucket(
                    MAX_REQUESTS, REFILL_RATE
                )

            if not buckets[client_ip].allow_request():
                return jsonify({
                    "error": "Rate limit exceeded"
                }), 429

            return func(*args, **kwargs)
        return wrapper
    return decorator
