cache = {}

def fetch_from_api(key):
    # Simulating API call
    print("Fetching from API...")
    return f"Data for {key}"

def get_data(key):
    # Check cache
    if key in cache:
        print("Returning from cache")
        return cache[key]

    # Fetch fresh data
    data = fetch_from_api(key)

    # Store in cache
    cache[key] = data

    return data
